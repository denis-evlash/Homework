public class Main {
    public static void main(String[] args) {
        System.out.println();
        System.out.println("Pupkin Wasilii Wasilevich");
        System.out.println("age 20");
        System.out.println("height 176cm");
        System.out.println();
        System.out.println("Pupkin Wasilii Ivanowich");
        System.out.println("age 30");
        System.out.println("height 180cm");
        System.out.println();
        System.out.println("Pupkin Wasilii Evgenevich");
        System.out.println("age 40");
        System.out.println("height 200cm");
        System.out.println();
        System.out.printf("%.2f %.2f %.2f", 3.222, 4.333, 5.444);
        System.out.println();
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.print("_");
        System.out.println();
        System.out.print("|");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print("|");
        System.out.println();
        System.out.print("|");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print("|");
        System.out.println();
        System.out.print("|");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print(" ");
        System.out.print("|");
        System.out.println();
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");
        System.out.print("-");


    }
}